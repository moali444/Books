import './ShippingData.scss';

const ShippingData = () => {
  return (
    <div>ShippingData</div>
  )
}

export default ShippingData